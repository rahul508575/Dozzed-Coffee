# Dozzed Coffee & Eatery (React + Vite)

## Local run
    npm install
    npm run dev

## Content badalna
- Details / phone / timings: src/data/site.js
- Menu: src/data/menu.js
- Photos: public/img/ (hero.jpg, about.jpg, g1.jpg ... g5.jpg)

## Render par deploy (Static Site)
- Build Command: npm install && npm run build
- Publish Directory: dist
