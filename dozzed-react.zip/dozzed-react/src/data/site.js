// Client ki details yahin se badlo
export const site = {
  name: 'Dozzed Coffee & Eatery',
  phone: '099905 56199',
  wa: '919990556199', // WhatsApp number (country code ke saath)
  address: 'C4A 46, Block C4A, Janakpuri, New Delhi, Delhi 110058',
  rating: '4.7',
  reviews: '120',
  price: '₹200–1,200',
  opens: 11, // TODO: client se opening time confirm karo (24h)
  closes: 3, // 3 AM
  maps: 'https://www.google.com/maps/search/?api=1&query=Dozzed+Coffee+%26+Eatery+Janakpuri',
  mapEmbed:
    'https://maps.google.com/maps?q=Dozzed+Coffee+%26+Eatery+Janakpuri+New+Delhi&output=embed',
  insta: '#', // TODO: Instagram link
};
