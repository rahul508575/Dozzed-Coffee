// SAMPLE menu - client ka real menu aane par replace karo
export const menu = {
  Coffee: [
    { name: 'Cold Coffee', desc: 'Thick, chilled, with a scoop of vanilla', price: '₹220' },
    { name: 'Hazelnut Latte', desc: 'Espresso, steamed milk, hazelnut syrup', price: '₹250' },
    { name: 'Cappuccino', desc: 'Classic, with a proper foam cap', price: '₹200' },
    { name: 'Affogato', desc: 'Hot espresso poured over ice cream', price: '₹280' },
  ],
  Food: [
    { name: 'Peri Peri Fries', desc: 'Crisp fries tossed in spicy peri peri', price: '₹190' },
    { name: 'Creamy Pasta', desc: 'White sauce, herbs, garlic bread on the side', price: '₹320' },
    { name: 'Loaded Nachos', desc: 'Cheese, salsa, jalapeños, sour cream', price: '₹300' },
    { name: 'Crispy Wings', desc: 'Tossed in house sauce, served hot', price: '₹340' },
  ],
  Sweet: [
    { name: 'Brownie Sizzler', desc: 'Warm brownie, ice cream, chocolate sauce', price: '₹320' },
    { name: 'Waffle Stack', desc: 'Belgian waffles with Nutella and fruit', price: '₹290' },
    { name: 'Cheesecake Slice', desc: 'Baked, creamy, fresh every day', price: '₹260' },
    { name: 'Churro Bites', desc: 'Cinnamon sugar with chocolate dip', price: '₹240' },
  ],
};
