import { site } from '../data/site';
import { useReveal } from '../hooks/useReveal';

export default function Visit() {
  const [r1, c1] = useReveal();
  const [r2, c2] = useReveal();
  return (
    <section className="visit" id="visit">
      <div className="wrap">
        <div ref={r1} className={`info ${c1}`}>
          <h2>Find us</h2>
          <p><b>Address</b>{site.address}</p>
          <p><b>Hours</b>Open daily, closes at 3 AM</p>
          <p><b>Call</b><a href={`tel:${site.phone.replace(/\s+/g, '')}`}>{site.phone}</a></p>
          <a className="btn solid" href={site.maps} target="_blank" rel="noopener noreferrer">Get directions</a>
        </div>
        <div ref={r2} className={`map ${c2}`}>
          <iframe
            title="Map to Dozzed Coffee & Eatery"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            src={site.mapEmbed}
          />
        </div>
      </div>
    </section>
  );
}
