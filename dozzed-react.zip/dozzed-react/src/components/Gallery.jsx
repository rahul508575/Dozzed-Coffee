import { useReveal } from '../hooks/useReveal';

const shots = ['Outdoor seating at night', 'Food on the table', 'Cafe entrance', 'Garden corner', 'Coffee and dessert'];

export default function Gallery() {
  const [r1, c1] = useReveal();
  const [r2, c2] = useReveal();
  const [r3, c3] = useReveal();
  return (
    <>
      <section id="gallery">
        <div className="wrap">
          <h2 ref={r1} className={c1}>Evenings at Dozzed</h2>
          <p ref={r2} className={`lead ${c2}`}>Lantern light, green stripes and full tables. Here's a look inside.</p>
          <div ref={r3} className={`grid ${c3}`}>
            {shots.map((label) => (
              <div className="g" key={label} role="img" aria-label={label} />
            ))}
          </div>
        </div>
      </section>
      <div className="checker" aria-hidden="true" />
    </>
  );
}
