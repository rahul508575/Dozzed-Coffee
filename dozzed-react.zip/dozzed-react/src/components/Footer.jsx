import { site } from '../data/site';

export default function Footer() {
  return (
    <footer>
      <div className="wrap">
        <a href="#top" className="logo">dozzed<span>.</span></a>
        <p>{site.name} · {site.address}</p>
        <p>© {new Date().getFullYear()} Dozzed Coffee &amp; Eatery. All rights reserved.</p>
      </div>
    </footer>
  );
}
