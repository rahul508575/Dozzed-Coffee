import { useReveal } from '../hooks/useReveal';

export default function About() {
  const [r1, c1] = useReveal();
  const [r2, c2] = useReveal();
  return (
    <section className="about" id="about">
      <div className="wrap">
        <div ref={r1} className={`photo ${c1}`} role="img" aria-label="Seating area at Dozzed" />
        <div ref={r2} className={c2}>
          <h2>A café for people who aren't ready to go home yet</h2>
          <p className="lead">
            Dozzed is a neighbourhood coffee shop and eatery in Janakpuri. Warm lights, green
            corners and a menu built for long conversations.
          </p>
          <p className="lead">
            Grab a table outside under the fairy lights, or settle in indoors with a cold coffee
            and something hot from the kitchen.
          </p>
          <ul className="perks">
            <li>Outdoor garden seating</li>
            <li>Open till 3 AM</li>
            <li>Table reservations</li>
            <li>Order online</li>
          </ul>
        </div>
      </div>
    </section>
  );
}
