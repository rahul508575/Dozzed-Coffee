import { useState } from 'react';
import { menu } from '../data/menu';

export default function Menu() {
  const cats = Object.keys(menu);
  const [active, setActive] = useState(cats[0]);

  return (
    <section className="menu" id="menu">
      <div className="wrap">
        <h2>What's on the table</h2>
        <p className="lead">A few favourites to start with. Full menu on Google or ask our team at the counter.</p>
        <div className="tabs" role="tablist">
          {cats.map((c) => (
            <button key={c} className="tab" role="tab" aria-selected={active === c} onClick={() => setActive(c)}>
              {c}
            </button>
          ))}
        </div>
        {/* key badalne par item animation dobara chalti hai */}
        <div className="panel show" role="tabpanel" key={active}>
          {menu[active].map((it) => (
            <div className="item" key={it.name}>
              <div>
                <h3>{it.name}</h3>
                <p>{it.desc}</p>
              </div>
              <span className="pr">{it.price}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
