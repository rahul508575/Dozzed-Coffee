import { site } from '../data/site';

export default function Facts() {
  const items = [
    [`${site.rating} ★`, 'Google rating'],
    [site.reviews, 'Guest reviews'],
    [site.price, 'Per person'],
    ['3 AM', 'We close late'],
  ];
  return (
    <div className="facts">
      <div className="wrap">
        {items.map(([big, small]) => (
          <div key={small}><b>{big}</b><span>{small}</span></div>
        ))}
      </div>
    </div>
  );
}
