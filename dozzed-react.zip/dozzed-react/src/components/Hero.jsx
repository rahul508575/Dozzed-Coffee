import { useEffect, useState } from 'react';
import { site } from '../data/site';
import { useIsOpen, formatHour } from '../hooks/useIsOpen';

const bulbs = [[75,42],[150,56],[225,42],[375,42],[450,56],[525,42],[675,42],[750,56],[825,42],[975,42],[1050,56],[1125,42]];

export default function Hero() {
  const isOpen = useIsOpen();
  const [lit, setLit] = useState(false);

  // page load par fairy lights ek-ek karke on hoti hain
  useEffect(() => {
    const id = requestAnimationFrame(() => setLit(true));
    return () => cancelAnimationFrame(id);
  }, []);

  return (
    <>
      <section className="hero" id="hero">
        <div className={`lights ${lit ? 'on' : ''}`} aria-hidden="true">
          <svg viewBox="0 0 1200 90" preserveAspectRatio="none">
            <path d="M0 8 Q 150 70 300 8 T 600 8 T 900 8 T 1200 8" fill="none" stroke="#2c6d58" strokeWidth="2" />
            {bulbs.map(([x, y], i) => (
              <circle key={i} className="bulb" style={{ '--i': i }} cx={x} cy={y + 8} r="8" />
            ))}
          </svg>
        </div>
        <div className="wrap">
          <div>
            <div className={`status ${isOpen ? 'open' : ''}`}>
              <span className="dot" />
              {isOpen ? 'Open now · kitchen runs till 3 AM' : `Closed right now · opens at ${formatHour(site.opens)}`}
            </div>
            <h1>Stay up a little longer. Order one more.</h1>
            <p>
              Coffee, comfort food and a green garden corner in Janakpuri. Come for a quick cup or
              stay for the late-night chatter.
            </p>
            <div className="cta">
              <a className="btn solid" href="#reserve">Reserve a table</a>
              <a className="btn ghost" href="#menu">See the menu</a>
            </div>
          </div>
          <div className="frame" role="img" aria-label="Dozzed Coffee and Eatery entrance at night">
            <div className="steam" aria-hidden="true"><i /><i /><i /></div>
          </div>
        </div>
      </section>
      <div className="checker" aria-hidden="true" />
    </>
  );
}
