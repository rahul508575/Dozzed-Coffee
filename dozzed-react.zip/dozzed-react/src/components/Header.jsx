import { useEffect, useState } from 'react';

const links = [
  ['#about', 'Our story'],
  ['#menu', 'Menu'],
  ['#gallery', 'Gallery'],
  ['#visit', 'Find us'],
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header id="top" className={scrolled ? 'scrolled' : ''}>
      <div className="wrap nav">
        <a href="#top" className="logo">dozzed<span>.</span></a>
        <button className="burger" aria-label="Open menu" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
          ☰
        </button>
        <ul className={`links ${open ? 'open' : ''}`} onClick={() => setOpen(false)}>
          {links.map(([href, label]) => (
            <li key={href}><a href={href}>{label}</a></li>
          ))}
          <li><a className="btn solid" href="#reserve">Reserve a table</a></li>
        </ul>
      </div>
    </header>
  );
}
