import { useState } from 'react';
import { site } from '../data/site';

// Aaj ki date (India) YYYY-MM-DD format mein
const todayIST = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata' }).format(new Date());

export default function Reserve() {
  const [form, setForm] = useState({ name: '', guests: 2, date: '', time: '' });
  const [err, setErr] = useState('');

  const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const onSubmit = (e) => {
    e.preventDefault();
    const g = Number(form.guests);
    if (!form.name.trim() || g < 1 || g > 30 || !form.date || !form.time) {
      setErr('Please fill in your name, guests, date and time.');
      return;
    }
    setErr('');
    const msg =
      `Hi ${site.name}, I'd like to reserve a table.\n` +
      `Name: ${form.name.trim()}\nGuests: ${g}\nDate: ${form.date}\nTime: ${form.time}`;
    window.open(`https://wa.me/${site.wa}?text=${encodeURIComponent(msg)}`, '_blank', 'noopener');
  };

  return (
    <section className="reserve" id="reserve">
      <div className="wrap">
        <div>
          <h2>Book your table</h2>
          <p className="lead">
            Fill in the details and we'll open WhatsApp with your request ready to send. Prefer a call? Dial{' '}
            <a href={`tel:${site.phone.replace(/\s+/g, '')}`}><b>{site.phone}</b></a>.
          </p>
        </div>
        <form onSubmit={onSubmit} noValidate>
          {err && <p className="err full" role="alert">{err}</p>}
          <div className="full">
            <label htmlFor="name">Your name</label>
            <input id="name" name="name" value={form.name} onChange={onChange} required />
          </div>
          <div>
            <label htmlFor="guests">Guests</label>
            <input id="guests" name="guests" type="number" min="1" max="30" value={form.guests} onChange={onChange} required />
          </div>
          <div>
            <label htmlFor="date">Date</label>
            <input id="date" name="date" type="date" min={todayIST()} value={form.date} onChange={onChange} required />
          </div>
          <div className="full">
            <label htmlFor="time">Time</label>
            <input id="time" name="time" type="time" value={form.time} onChange={onChange} required />
          </div>
          <div className="full">
            <button className="btn solid" type="submit">Send on WhatsApp</button>
          </div>
        </form>
      </div>
    </section>
  );
}
