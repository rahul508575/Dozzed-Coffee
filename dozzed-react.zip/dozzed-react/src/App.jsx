import Header from './components/Header';
import Hero from './components/Hero';
import Facts from './components/Facts';
import About from './components/About';
import Menu from './components/Menu';
import Gallery from './components/Gallery';
import Reserve from './components/Reserve';
import Visit from './components/Visit';
import Footer from './components/Footer';

export default function App() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <Facts />
        <About />
        <Menu />
        <Gallery />
        <Reserve />
        <Visit />
      </main>
      <Footer />
    </>
  );
}
