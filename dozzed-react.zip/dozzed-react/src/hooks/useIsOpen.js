import { useEffect, useState } from 'react';
import { site } from '../data/site';

// Hamesha India time (IST) ke hisaab se, user ke device ki timezone se nahi
function istHour() {
  return (
    Number(
      new Intl.DateTimeFormat('en-GB', { hour: '2-digit', hour12: false, timeZone: 'Asia/Kolkata' }).format(new Date())
    ) % 24
  );
}

const calc = () => {
  const h = istHour();
  return h >= site.opens || h < site.closes;
};

export function useIsOpen() {
  const [open, setOpen] = useState(calc);
  useEffect(() => {
    const id = setInterval(() => setOpen(calc()), 60000);
    return () => clearInterval(id);
  }, []);
  return open;
}

export function formatHour(h) {
  return `${h % 12 || 12} ${h >= 12 ? 'PM' : 'AM'}`;
}
