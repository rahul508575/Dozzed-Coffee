<?php
date_default_timezone_set('Asia/Kolkata');

/* ============ SITE CONFIG (yahin se details change karo) ============ */
$site = [
  'name'    => 'Dozzed Coffee & Eatery',
  'phone'   => '099905 56199',
  'wa'      => '919990556199',           // WhatsApp number (country code ke saath)
  'address' => 'C4A 46, Block C4A, Janakpuri, New Delhi, Delhi 110058',
  'rating'  => '4.7',
  'reviews' => '120',
  'price'   => '₹200–1,200',
  'opens'   => 11,                        // TODO: client se opening time confirm karo (24h format)
  'closes'  => 3,                         // 3 AM
  'maps'    => 'https://www.google.com/maps/search/?api=1&query=Dozzed+Coffee+%26+Eatery+Janakpuri',
  'insta'   => '#',                       // TODO: Instagram link
];

/* SAMPLE menu - client ka real menu aane par replace karo */
$menu = [
  'Coffee' => [
    ['Cold Coffee',        'Thick, chilled, with a scoop of vanilla',        '₹220'],
    ['Hazelnut Latte',     'Espresso, steamed milk, hazelnut syrup',         '₹250'],
    ['Cappuccino',         'Classic, with a proper foam cap',                '₹200'],
    ['Affogato',           'Hot espresso poured over ice cream',             '₹280'],
  ],
  'Food' => [
    ['Peri Peri Fries',    'Crisp fries tossed in spicy peri peri',          '₹190'],
    ['Creamy Pasta',       'White sauce, herbs, garlic bread on the side',   '₹320'],
    ['Loaded Nachos',      'Cheese, salsa, jalapeños, sour cream',           '₹300'],
    ['Crispy Wings',       'Tossed in house sauce, served hot',              '₹340'],
  ],
  'Sweet' => [
    ['Brownie Sizzler',    'Warm brownie, ice cream, chocolate sauce',       '₹320'],
    ['Waffle Stack',       'Belgian waffles with Nutella and fruit',         '₹290'],
    ['Cheesecake Slice',   'Baked, creamy, fresh every day',                 '₹260'],
    ['Churro Bites',       'Cinnamon sugar with chocolate dip',              '₹240'],
  ],
];

/* Live open/closed status */
$h = (int)date('G');
$isOpen = ($h >= $site['opens'] || $h < $site['closes']);

/* Reservation form -> WhatsApp pe redirect */
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reserve'])) {
  $n = trim($_POST['name'] ?? '');
  $g = (int)($_POST['guests'] ?? 0);
  $d = trim($_POST['date'] ?? '');
  $t = trim($_POST['time'] ?? '');
  if ($n === '' || $g < 1 || $g > 30 || $d === '' || $t === '') {
    $err = 'Please fill in your name, guests, date and time.';
  } else {
    $msg = "Hi {$site['name']}, I'd like to reserve a table.\nName: $n\nGuests: $g\nDate: $d\nTime: $t";
    header('Location: https://wa.me/' . $site['wa'] . '?text=' . rawurlencode($msg));
    exit;
  }
}
function e($s){ return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($site['name']) ?> | Late-night coffee &amp; food in Janakpuri</title>
<meta name="description" content="Coffee, good food and a calm garden seating in Janakpuri, New Delhi. Open late till 3 AM. Reserve a table or order online.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600&family=Young+Serif&display=swap" rel="stylesheet">
<style>
:root{
  --forest:#123B30; --night:#0A2820; --pine:#1C5242;
  --lamp:#F4B942; --milk:#F6F1E4; --chai:#8A5A36; --ink:#0E1F1A;
  --serif:'Young Serif',Georgia,serif; --sans:'Outfit',system-ui,sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth;scroll-padding-top:70px}
body{font-family:var(--sans);background:var(--night);color:var(--milk);line-height:1.6;font-size:17px;overflow-x:hidden}
img{max-width:100%;display:block}
a{color:inherit}
:focus-visible{outline:3px solid var(--lamp);outline-offset:3px}
.wrap{width:min(1120px,92%);margin-inline:auto}
h1,h2,h3{font-family:var(--serif);font-weight:400;line-height:1.1}
h2{font-size:clamp(1.9rem,4.5vw,3rem);margin-bottom:14px}
p.lead{max-width:56ch;opacity:.85}
section{padding:92px 0}

/* checkerboard strip - cafe ke green/white floor se inspired */
.checker{height:28px;background:
  conic-gradient(var(--milk) 25%,var(--pine) 0 50%,var(--milk) 0 75%,var(--pine) 0) 0 0/56px 56px}

/* buttons */
.btn{display:inline-block;padding:14px 26px;border-radius:999px;font-weight:500;text-decoration:none;border:2px solid var(--lamp);transition:transform .2s,background .2s,color .2s;cursor:pointer;font-family:inherit;font-size:1rem}
.btn.solid{background:var(--lamp);color:var(--ink)}
.btn.solid:hover{transform:translateY(-3px);background:#ffc95e}
.btn.ghost{background:transparent;color:var(--milk)}
.btn.ghost:hover{background:var(--lamp);color:var(--ink)}

/* header */
header{position:fixed;inset:0 0 auto 0;z-index:50;transition:background .3s,box-shadow .3s}
header.scrolled{background:rgba(10,40,32,.95);backdrop-filter:blur(8px);box-shadow:0 2px 20px rgba(0,0,0,.3)}
.nav{display:flex;align-items:center;justify-content:space-between;height:70px}
.logo{font-family:var(--serif);font-size:1.7rem;text-decoration:none;letter-spacing:.5px}
.logo span{color:var(--lamp)}
.links{display:flex;gap:30px;align-items:center;list-style:none}
.links a{text-decoration:none;font-size:.97rem;opacity:.9;position:relative}
.links a:not(.btn)::after{content:"";position:absolute;left:0;bottom:-4px;height:2px;width:0;background:var(--lamp);transition:width .25s}
.links a:not(.btn):hover::after{width:100%}
.links .btn{padding:9px 20px}
.burger{display:none;background:none;border:0;color:var(--milk);font-size:1.8rem;cursor:pointer}

/* hero */
.hero{position:relative;min-height:100vh;display:flex;align-items:center;padding:130px 0 90px;
  background:radial-gradient(900px 500px at 78% 40%,rgba(244,185,66,.16),transparent 70%),linear-gradient(180deg,var(--night),var(--forest))}
.lights{position:absolute;top:70px;left:0;width:100%;height:90px;pointer-events:none}
.lights svg{width:100%;height:100%}
.bulb{fill:#6b5a2e;transition:fill .4s}
.on .bulb{animation:warm .9s forwards;animation-delay:calc(var(--i)*140ms + .3s)}
@keyframes warm{0%{fill:#6b5a2e}60%{fill:#ffe39a;filter:drop-shadow(0 0 10px #F4B942)}100%{fill:var(--lamp);filter:drop-shadow(0 0 6px rgba(244,185,66,.8))}}
.hero .wrap{display:grid;grid-template-columns:1.1fr .9fr;gap:56px;align-items:center;position:relative;z-index:2}
.status{display:inline-flex;align-items:center;gap:10px;padding:8px 16px;border:1px solid rgba(246,241,228,.25);border-radius:999px;font-size:.93rem;margin-bottom:26px}
.dot{width:10px;height:10px;border-radius:50%;background:#e25b4a}
.status.open .dot{background:#4fd18b;box-shadow:0 0 0 0 rgba(79,209,139,.7);animation:pulse 2s infinite}
@keyframes pulse{70%{box-shadow:0 0 0 10px rgba(79,209,139,0)}100%{box-shadow:0 0 0 0 rgba(79,209,139,0)}}
.hero h1{font-size:clamp(2.6rem,6.8vw,5rem);margin-bottom:22px}
.hero h1 em{font-style:normal;color:var(--lamp)}
.hero p{max-width:46ch;font-size:1.1rem;opacity:.88;margin-bottom:34px}
.cta{display:flex;gap:14px;flex-wrap:wrap}
.frame{position:relative;aspect-ratio:4/5;border-radius:200px 200px 24px 24px;border:6px solid var(--milk);overflow:hidden;
  background:url(assets/img/hero.jpg) center/cover,linear-gradient(160deg,var(--pine),var(--night));box-shadow:0 30px 60px rgba(0,0,0,.45)}
.frame::after{content:"dozzed";position:absolute;inset:auto 0 24px 0;text-align:center;font-family:var(--serif);font-size:2.4rem;color:var(--milk);text-shadow:0 2px 14px rgba(0,0,0,.6)}
.steam{position:absolute;left:50%;top:18%;width:60px;height:90px;transform:translateX(-50%);opacity:.5}
.steam i{position:absolute;bottom:0;width:6px;height:50px;border-radius:6px;background:linear-gradient(var(--milk),transparent);animation:rise 3.4s infinite ease-in-out}
.steam i:nth-child(1){left:10px}.steam i:nth-child(2){left:27px;animation-delay:.9s}.steam i:nth-child(3){left:44px;animation-delay:1.7s}
@keyframes rise{0%{transform:translateY(20px) scaleY(.6);opacity:0}40%{opacity:.8}100%{transform:translateY(-40px) scaleY(1.2);opacity:0}}

/* facts */
.facts{background:var(--milk);color:var(--ink);padding:34px 0}
.facts .wrap{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;text-align:center}
.facts b{display:block;font-family:var(--serif);font-weight:400;font-size:2rem;color:var(--forest)}
.facts span{font-size:.95rem;opacity:.75}

/* about */
.about .wrap{display:grid;grid-template-columns:.9fr 1.1fr;gap:60px;align-items:center}
.photo{aspect-ratio:1/1;border-radius:24px;background:url(assets/img/about.jpg) center/cover,linear-gradient(135deg,var(--chai),var(--forest));border:6px solid var(--milk);transform:rotate(-2deg)}
.about p+p{margin-top:14px}
.perks{display:grid;grid-template-columns:1fr 1fr;gap:14px 24px;margin-top:28px;list-style:none}
.perks li{padding-left:26px;position:relative}
.perks li::before{content:"";position:absolute;left:0;top:.5em;width:12px;height:12px;background:var(--lamp);border-radius:3px;transform:rotate(45deg)}

/* menu */
.menu{background:var(--forest)}
.tabs{display:flex;gap:10px;margin:26px 0 34px;flex-wrap:wrap}
.tab{padding:10px 24px;border-radius:999px;border:2px solid rgba(246,241,228,.3);background:none;color:var(--milk);font:inherit;cursor:pointer;transition:all .2s}
.tab[aria-selected=true]{background:var(--lamp);border-color:var(--lamp);color:var(--ink)}
.panel{display:none;grid-template-columns:1fr 1fr;gap:6px 56px}
.panel.show{display:grid}
.item{display:flex;justify-content:space-between;gap:18px;padding:18px 0;border-bottom:1px dashed rgba(246,241,228,.28);animation:swap .4s both}
.item:nth-child(2){animation-delay:.05s}.item:nth-child(3){animation-delay:.1s}.item:nth-child(4){animation-delay:.15s}
@keyframes swap{from{opacity:0;transform:translateX(-14px)}to{opacity:1;transform:none}}
.item h3{font-size:1.25rem;margin-bottom:4px}
.item p{font-size:.93rem;opacity:.78}
.item .pr{font-family:var(--serif);color:var(--lamp);font-size:1.15rem;white-space:nowrap}

/* gallery */
.grid{display:grid;grid-template-columns:repeat(4,1fr);grid-auto-rows:190px;gap:14px;margin-top:34px}
.g{border-radius:18px;overflow:hidden;position:relative;background-size:cover;background-position:center;transition:transform .35s}
.g:hover{transform:scale(1.03)}
.g:nth-child(1){grid-column:span 2;grid-row:span 2;background-image:url(assets/img/g1.jpg),linear-gradient(135deg,var(--pine),var(--night))}
.g:nth-child(2){background-image:url(assets/img/g2.jpg),linear-gradient(135deg,var(--chai),var(--night))}
.g:nth-child(3){background-image:url(assets/img/g3.jpg),linear-gradient(135deg,#2c6d58,var(--forest))}
.g:nth-child(4){grid-column:span 2;background-image:url(assets/img/g4.jpg),linear-gradient(135deg,var(--forest),var(--chai))}
.g:nth-child(5){background-image:url(assets/img/g5.jpg),linear-gradient(135deg,var(--lamp),var(--chai))}

/* reserve */
.reserve{background:var(--milk);color:var(--ink)}
.reserve .wrap{display:grid;grid-template-columns:1fr 1fr;gap:56px;align-items:start}
.reserve p.lead{opacity:.8}
form{display:grid;grid-template-columns:1fr 1fr;gap:16px}
form .full{grid-column:1/-1}
label{display:block;font-size:.9rem;margin-bottom:6px;font-weight:500}
input{width:100%;padding:13px 14px;border-radius:12px;border:2px solid #cfc8b4;background:#fff;font:inherit;color:var(--ink);transition:border-color .2s}
input:focus{outline:none;border-color:var(--forest)}
.err{color:#b3261e;font-size:.95rem;margin-bottom:12px}
.reserve .btn.solid{border-color:var(--forest);background:var(--forest);color:var(--milk)}
.reserve .btn.solid:hover{background:var(--pine)}

/* visit */
.visit .wrap{display:grid;grid-template-columns:.8fr 1.2fr;gap:50px}
.info p{margin-bottom:18px}
.info b{display:block;font-family:var(--serif);font-weight:400;color:var(--lamp);font-size:1.15rem}
.info a{text-decoration:none;border-bottom:1px solid var(--lamp)}
.map{border-radius:20px;overflow:hidden;border:6px solid var(--milk);min-height:380px}
.map iframe{width:100%;height:100%;min-height:380px;border:0;filter:saturate(.85)}

footer{background:#06191A;padding:40px 0;text-align:center;font-size:.92rem}
footer .logo{display:inline-block;margin-bottom:10px}
footer p{opacity:.65}

/* scroll reveal (sirf kuch sections par) */
.rv{opacity:0;transform:translateY(26px);transition:opacity .7s,transform .7s}
.rv.in{opacity:1;transform:none}

@media(max-width:860px){
  section{padding:68px 0}
  .burger{display:block}
  .links{position:absolute;top:70px;left:0;right:0;flex-direction:column;background:var(--night);padding:24px 0;gap:20px;display:none}
  .links.open{display:flex}
  .hero .wrap,.about .wrap,.reserve .wrap,.visit .wrap{grid-template-columns:1fr}
  .frame{max-width:340px;margin:0 auto}
  .facts .wrap{grid-template-columns:1fr 1fr}
  .panel{grid-template-columns:1fr}
  .grid{grid-template-columns:1fr 1fr;grid-auto-rows:150px}
  .g:nth-child(1){grid-column:span 2}
  .perks{grid-template-columns:1fr}
}
@media(prefers-reduced-motion:reduce){
  *{animation:none!important;transition:none!important}
  .rv{opacity:1;transform:none}.bulb{fill:var(--lamp)}
}
</style>
</head>
<body>

<header id="top">
  <div class="wrap nav">
    <a href="#top" class="logo">dozzed<span>.</span></a>
    <button class="burger" aria-label="Open menu" aria-expanded="false">☰</button>
    <ul class="links">
      <li><a href="#about">Our story</a></li>
      <li><a href="#menu">Menu</a></li>
      <li><a href="#gallery">Gallery</a></li>
      <li><a href="#visit">Find us</a></li>
      <li><a class="btn solid" href="#reserve">Reserve a table</a></li>
    </ul>
  </div>
</header>

<main>
<!-- HERO -->
<section class="hero" id="hero">
  <div class="lights" aria-hidden="true">
    <svg viewBox="0 0 1200 90" preserveAspectRatio="none">
      <path d="M0 8 Q 150 70 300 8 T 600 8 T 900 8 T 1200 8" fill="none" stroke="#2c6d58" stroke-width="2"/>
      <?php
        $pts = [[75,42],[150,56],[225,42],[375,42],[450,56],[525,42],[675,42],[750,56],[825,42],[975,42],[1050,56],[1125,42]];
        foreach ($pts as $i => $p) echo '<circle class="bulb" style="--i:'.$i.'" cx="'.$p[0].'" cy="'.($p[1]+8).'" r="8"/>';
      ?>
    </svg>
  </div>
  <div class="wrap">
    <div>
      <div class="status <?= $isOpen ? 'open' : '' ?>">
        <span class="dot"></span>
        <?= $isOpen ? 'Open now · kitchen runs till 3 AM' : 'Closed right now · opens at ' . date('g A', strtotime($site['opens'].':00')) ?>
      </div>
      <h1>Stay up a little longer. Order one more.</h1>
      <p>Coffee, comfort food and a green garden corner in Janakpuri. Come for a quick cup or stay for the late-night chatter.</p>
      <div class="cta">
        <a class="btn solid" href="#reserve">Reserve a table</a>
        <a class="btn ghost" href="#menu">See the menu</a>
      </div>
    </div>
    <div class="frame" role="img" aria-label="Dozzed Coffee and Eatery entrance at night">
      <div class="steam" aria-hidden="true"><i></i><i></i><i></i></div>
    </div>
  </div>
</section>

<div class="checker" aria-hidden="true"></div>

<!-- FACTS -->
<div class="facts">
  <div class="wrap">
    <div><b><?= e($site['rating']) ?> ★</b><span>Google rating</span></div>
    <div><b><?= e($site['reviews']) ?></b><span>Guest reviews</span></div>
    <div><b><?= e($site['price']) ?></b><span>Per person</span></div>
    <div><b>3 AM</b><span>We close late</span></div>
  </div>
</div>

<!-- ABOUT -->
<section class="about" id="about">
  <div class="wrap">
    <div class="photo rv" role="img" aria-label="Seating area at Dozzed"></div>
    <div class="rv">
      <h2>A café for people who aren't ready to go home yet</h2>
      <p class="lead">Dozzed is a neighbourhood coffee shop and eatery in Janakpuri. Warm lights, green corners and a menu built for long conversations.</p>
      <p class="lead">Grab a table outside under the fairy lights, or settle in indoors with a cold coffee and something hot from the kitchen.</p>
      <ul class="perks">
        <li>Outdoor garden seating</li>
        <li>Open till 3 AM</li>
        <li>Table reservations</li>
        <li>Order online</li>
      </ul>
    </div>
  </div>
</section>

<!-- MENU -->
<section class="menu" id="menu">
  <div class="wrap">
    <h2>What's on the table</h2>
    <p class="lead">A few favourites to start with. Full menu on Google or ask our team at the counter.</p>
    <div class="tabs" role="tablist">
      <?php $first = true; foreach ($menu as $cat => $_): ?>
        <button class="tab" role="tab" aria-selected="<?= $first ? 'true' : 'false' ?>" data-t="<?= e($cat) ?>"><?= e($cat) ?></button>
      <?php $first = false; endforeach; ?>
    </div>
    <?php $first = true; foreach ($menu as $cat => $items): ?>
      <div class="panel <?= $first ? 'show' : '' ?>" data-p="<?= e($cat) ?>" role="tabpanel">
        <?php foreach ($items as $it): ?>
          <div class="item">
            <div><h3><?= e($it[0]) ?></h3><p><?= e($it[1]) ?></p></div>
            <span class="pr"><?= e($it[2]) ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    <?php $first = false; endforeach; ?>
  </div>
</section>

<!-- GALLERY -->
<section id="gallery">
  <div class="wrap">
    <h2 class="rv">Evenings at Dozzed</h2>
    <p class="lead rv">Lantern light, green stripes and full tables. Here's a look inside.</p>
    <div class="grid rv">
      <div class="g" role="img" aria-label="Outdoor seating at night"></div>
      <div class="g" role="img" aria-label="Food on the table"></div>
      <div class="g" role="img" aria-label="Cafe entrance"></div>
      <div class="g" role="img" aria-label="Garden corner"></div>
      <div class="g" role="img" aria-label="Coffee and dessert"></div>
    </div>
  </div>
</section>

<div class="checker" aria-hidden="true"></div>

<!-- RESERVE -->
<section class="reserve" id="reserve">
  <div class="wrap">
    <div>
      <h2>Book your table</h2>
      <p class="lead">Fill in the details and we'll open WhatsApp with your request ready to send. Prefer a call? Dial <a href="tel:<?= e(preg_replace('/\s+/', '', $site['phone'])) ?>"><b><?= e($site['phone']) ?></b></a>.</p>
    </div>
    <form method="post" action="#reserve">
      <?php if ($err): ?><p class="err full"><?= e($err) ?></p><?php endif; ?>
      <div class="full"><label for="name">Your name</label><input id="name" name="name" required></div>
      <div><label for="guests">Guests</label><input id="guests" name="guests" type="number" min="1" max="30" value="2" required></div>
      <div><label for="date">Date</label><input id="date" name="date" type="date" min="<?= date('Y-m-d') ?>" required></div>
      <div class="full"><label for="time">Time</label><input id="time" name="time" type="time" required></div>
      <div class="full"><button class="btn solid" type="submit" name="reserve" value="1">Send on WhatsApp</button></div>
    </form>
  </div>
</section>

<!-- VISIT -->
<section class="visit" id="visit">
  <div class="wrap">
    <div class="info rv">
      <h2>Find us</h2>
      <p><b>Address</b><?= e($site['address']) ?></p>
      <p><b>Hours</b>Open daily, closes at 3 AM</p>
      <p><b>Call</b><a href="tel:<?= e(preg_replace('/\s+/', '', $site['phone'])) ?>"><?= e($site['phone']) ?></a></p>
      <a class="btn solid" href="<?= e($site['maps']) ?>" target="_blank" rel="noopener">Get directions</a>
    </div>
    <div class="map rv">
      <iframe title="Map to Dozzed Coffee & Eatery" loading="lazy" referrerpolicy="no-referrer-when-downgrade"
        src="https://maps.google.com/maps?q=Dozzed+Coffee+%26+Eatery+Janakpuri+New+Delhi&output=embed"></iframe>
    </div>
  </div>
</section>
</main>

<footer>
  <div class="wrap">
    <a href="#top" class="logo">dozzed<span>.</span></a>
    <p><?= e($site['name']) ?> · <?= e($site['address']) ?></p>
    <p>© <?= date('Y') ?> Dozzed Coffee &amp; Eatery. All rights reserved.</p>
  </div>
</footer>

<script>
  // lights switch on at load
  window.addEventListener('load',()=>document.querySelector('.lights').classList.add('on'));
  // sticky header
  const hd=document.querySelector('header');
  addEventListener('scroll',()=>hd.classList.toggle('scrolled',scrollY>30),{passive:true});
  // mobile nav
  const bg=document.querySelector('.burger'),ln=document.querySelector('.links');
  bg.addEventListener('click',()=>{const o=ln.classList.toggle('open');bg.setAttribute('aria-expanded',o)});
  ln.addEventListener('click',e=>{if(e.target.tagName==='A')ln.classList.remove('open')});
  // menu tabs
  document.querySelectorAll('.tab').forEach(t=>t.addEventListener('click',()=>{
    document.querySelectorAll('.tab').forEach(x=>x.setAttribute('aria-selected',x===t));
    document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('show',p.dataset.p===t.dataset.t));
  }));
  // reveal on scroll
  const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.15});
  document.querySelectorAll('.rv').forEach(el=>io.observe(el));
</script>
</body>
</html>
