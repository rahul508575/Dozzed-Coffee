Yahan client ke photos daalo (same naam se):
hero.jpg    - exterior / night shot (landscape)
about.jpg   - cafe seating ya food
g1.jpg g2.jpg g3.jpg g4.jpg g5.jpg - gallery photos
Photo na ho to bhi site chalegi (gradient fallback dikhega).
